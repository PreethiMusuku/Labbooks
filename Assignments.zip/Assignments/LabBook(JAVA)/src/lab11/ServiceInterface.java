package lab11;

public interface ServiceInterface {
 public void addValues(int id,String name,int salary,String designation);
	public Employee selectData(int nid);

}
