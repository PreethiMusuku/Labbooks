package lab2;
public class MediaItem extends Item 
{
    public MediaItem(){}
    
}
