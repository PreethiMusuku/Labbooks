package lab5;

public class lastNameNotNullException extends Exception 
{
	public lastNameNotNullException()
	{
		super("LastName Should not be Null");
	}
}
